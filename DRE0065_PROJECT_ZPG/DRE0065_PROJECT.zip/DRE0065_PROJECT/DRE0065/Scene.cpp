#include "Scene.h"
#include "tree.h"
#include "bushes.h"
#include "sphere.h"
#include "suzi_smooth.h"
#include "plain.h"

Scene::Scene(GLFWwindow* window) : window(window), currentScene(1)
{
    camera = new Camera(vec3(0.0f, 2.0f, 1.0f), vec3(0.0f, 1.0f, 0.0f), -90.0f, 0.0f);
    camera2 = new Camera(vec3(0.0f, 9.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f), -90.0f, -90.0f);
    projectionMatrix = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);

    glfwSetWindowUserPointer(window, this);
    setupScene1();
    setupScene2();
    setupScene3();
    setupScene4();
}

void Scene::setupScene1()
{
    float points[] =
    {
        0.0f, 0.5f, 0.0f,
        0.5f, -0.5f, 0.0f,
       -0.5f, -0.5f, 0.0f
    };

    triangleShader = new ShaderProgram("vertex_shader.glsl", "fragment_shader.glsl", camera);
    triangleShader->use();

    Model* triangleModel = new Model();
    triangleModel->setupModel(points, sizeof(points), 3, false);

    DrawableObject* triangleObject = new DrawableObject(triangleModel, triangleShader, 3, GL_TRIANGLES);
    scene1Objects.push_back(triangleObject);
}

void Scene::setupScene2()
{
    groundShader = new ShaderProgram("vertex_shader1.glsl", "fragment_shader.glsl", camera);
    treeShader = new ShaderProgram("vertex_shader1.glsl", "fragment_shader1.glsl", camera);
    bushShader = new ShaderProgram("vertex_shader1.glsl", "fragment_shader1.glsl", camera);

    light_sc2 = new Light(vec3(5.0f, 10.0f, -5.0f), vec3(1.0f, 1.0f, 1.0f), 1.0f);
    light_sc2->setPosition(vec3(-2.0f, 2.0f, 0.0f));

    int numLights = 5;
    float minDistanceLight = 3.5f;
    default_random_engine generator_light(static_cast<unsigned>(chrono::system_clock::now().time_since_epoch().count()));
    uniform_real_distribution<float> posXDistance(-5.0f, 5.0f), posZDistance(-15.0f, -5.0f);
    uniform_real_distribution<float> colorDistance(0.5f, 1.0f);
    for(int i=0; i < numLights; i++)
    {
        vec3 lightPos;
        bool validPosition = false;

        while(!validPosition)
        {
            lightPos = vec3(posXDistance(generator_light), 2.0f, posZDistance(generator_light));
            validPosition = true;

            for(auto existingLight : scene2Lights)
            {
                float distance = glm::length(lightPos - existingLight->getPosition());
                if(distance < minDistanceLight)
                {
                    validPosition = false;
                    break;
                }
            }
        }
        vec3 lightColor(colorDistance(generator_light), colorDistance(generator_light), colorDistance(generator_light));
        Light* newLight = new Light(lightPos, lightColor, 1.0f);

        TransformationComposite* lightTransform = new TransformationComposite();
        lightTransform->addComponent(new Translation(lightPos));
        newLight->setTransformation(lightTransform);
        scene2Lights.push_back(newLight);
    }

    Model* groundModel = new Model();
    groundModel->setupModel(plain, sizeof(plain), 6, true);

    DrawableObject* groundObject = new DrawableObject(groundModel, groundShader, 6, GL_TRIANGLES);

    TransformationComposite* groundTransform = new TransformationComposite();
    groundTransform->addComponent(new Scale(vec3(6.0f, 0.0f, 6.0f)));
    groundTransform->addComponent(new Translation(vec3(0.0f, -1.0f, -1.6f)));
    groundObject->transformationcom = *groundTransform;
    scene2Ground.push_back(groundObject);

    default_random_engine generator;
    uniform_real_distribution<float> posXDist(-5.0f, 5.0f), posZDist(-15.0f, -5.0f);
    uniform_real_distribution<float> treeScaleDist(0.05f, 0.1f), bushScaleDist(0.2f, 0.35f);
    uniform_real_distribution<float> rotationDist(0.0f, 360.0f);
    //int numTrees = 200, numBushes = 50;
    int numTrees = 300, numBushes = 300;
    float minDistance = 0.2f;
    vector<vec3> objectPositions;

    int rotationInterval = 30;
    for(int i=0; i < numTrees; i++)
    {
        bool validPosition = false;
        float posX, posZ;
        while(!validPosition)
        {
            posX = posXDist(generator);
            posZ = posZDist(generator);
            validPosition = true;
            for(int j = 0; j < objectPositions.size(); j++)
            {
                if(distance(vec3(posX, 0.0f, posZ), objectPositions[j]) < minDistance)
                {
                    validPosition = false;
                    break;
                }
            }
        }

        Model* treeModel = new Model();
        treeModel->setupModel(tree, sizeof(tree), 92814, true);
        DrawableObject* treeObject = new DrawableObject(treeModel, treeShader, 92814, GL_TRIANGLES);

        float randomScale = treeScaleDist(generator);
        float randomRotation = glm::radians(rotationDist(generator));

        TransformationComposite* treeTransform = new TransformationComposite();
        treeTransform->addComponent(new Translation(vec3(posX, 0.0f, posZ)));
        treeTransform->addComponent(new Rotation(randomRotation, vec3(0.0f, 1.0f, 0.0f)));
        treeTransform->addComponent(new Scale(vec3(randomScale, randomScale, randomScale)));

        if(i % rotationInterval == 0)
        {
            treeObject->transformationcom = *treeTransform;
            scene2Trees.push_back(treeObject);
        }
        else
        {
            treeObject->transformationcom = *treeTransform;
            scene2Trees.push_back(treeObject);
        }
        objectPositions.push_back(vec3(posX, 0.0f, posZ));
    }

    for(int i=0; i < numBushes; i++)
    {
        bool validPosition = false;
        float posX, posZ;
        while(!validPosition)
        {
            posX = posXDist(generator);
            posZ = posZDist(generator);
            validPosition = true;

            for(int j=0; j < objectPositions.size(); j++)
            {
                if(distance(vec3(posX, 0.0f, posZ), objectPositions[j]) < minDistance)
                {
                    validPosition = false;
                    break;
                }
            }
        }

        Model* bushModel = new Model();
        bushModel->setupModel(bushes, sizeof(bushes), 8730, true);

        DrawableObject* bushObject = new DrawableObject(bushModel, bushShader, 8730, GL_TRIANGLES);

        float randomScale = bushScaleDist(generator);
        float randomRotation = glm::radians(rotationDist(generator));

        TransformationComposite* bushTransform = new TransformationComposite();
        bushTransform->addComponent(new Translation(vec3(posX, 0.0f, posZ)));
        bushTransform->addComponent(new Rotation(randomRotation, vec3(0.0f, 1.0f, 0.0f)));
        bushTransform->addComponent(new Scale(vec3(randomScale, randomScale, randomScale)));
        bushObject->transformationcom = *bushTransform;

        scene2Bushes.push_back(bushObject);
        objectPositions.push_back(vec3(posX, 0.0f, posZ));
    }
}

void Scene::setupScene3()
{
    phongShader = new ShaderProgram("phong_vertex_shader.glsl", "phong_fragment_shader.glsl", camera2);

    light_sc3 = new Light(vec3(0.0f, 3.0f, 0.0f), vec3(1.0f, 1.0f, 1.0f), 1.0f);
    //light_sc3->setPosition(vec3(-2.0f, 2.0f, 0.0f));
    light_sc3->setPosition(vec3(0.0f, 0.0f, 0.0f));

    vec3 positions[4] =
    {
        vec3(-2.0f, 0.0f, -2.0f),
        vec3(2.0f, 0.0f, -2.0f),
        vec3(-2.0f, 0.0f, 2.0f),
        vec3(2.0f, 0.0f, 2.0f)
    };

    for(int i=0; i < 4; i++)
    {
        Model* sphereModel = new Model();
        sphereModel->setupModel(sphere, sizeof(sphere), 2880, true);

        DrawableObject* sphereObject = new DrawableObject(sphereModel, phongShader, 2880, GL_TRIANGLES);

        TransformationComposite* sphereTransform = new TransformationComposite();
        sphereTransform->addComponent(new Translation(positions[i]));
        sphereObject->transformationcom = *sphereTransform;

        scene3Objects.push_back(sphereObject);
    }
    ShaderProgram* phongShader = new ShaderProgram("phong_vertex_shader.glsl", "phong_fragment_shader.glsl", camera2);
}

void Scene::setupScene4()
{
    constantShader = new ShaderProgram("constant_vertex_shader.glsl", "constant_fragment_shader.glsl", camera2);
    lambertShader = new ShaderProgram("lambert_vertex_shader.glsl", "lambert_fragment_shader.glsl", camera2);
    blinnShader = new ShaderProgram("blinn_vertex_shader.glsl", "blinn_fragment_shader.glsl", camera2);

    light_sc4 = new Light(vec3(0.0f, 3.0f, 0.0f), vec3(1.0f, 1.0f, 1.0f), 1.0f);
    //light_sc4->setPosition(vec3(-2.0f, 2.0f, 0.0f));
    light_sc4->setPosition(vec3(0.0f, 0.0f, 0.0f));

    vec3 positions[4] =
    {
        vec3(-2.0f, 0.0f, -2.0f),
        vec3(2.0f, 0.0f, -2.0f),
        vec3(-2.0f, 0.0f, 2.0f),
        vec3(2.0f, 0.0f, 2.0f)
    };

    ShaderProgram* shaders[4] = { constantShader, lambertShader, phongShader, blinnShader };
    for(int i=0; i < 4; i++)
    {
        Model* model = new Model();
        if(i < 2) model->setupModel(suziSmooth, sizeof(suziSmooth), 2904, true);
        else model->setupModel(sphere, sizeof(sphere), 2880, true);

        DrawableObject* object = new DrawableObject(model, shaders[i], (i < 2 ? 2904 : 2880), GL_TRIANGLES);
        TransformationComposite* objTransform = new TransformationComposite();
        objTransform->addComponent(new Translation(positions[i]));
        object->transformationcom = *objTransform;
        scene4Objects.push_back(object);
    }
}

void Scene::currScene(int sceneNumber)
{
    currentScene = sceneNumber;
    if(currentScene == 1 || currentScene == 2) camera->resetPosition(vec3(0.0f, 2.0f, 1.0f), -90.0f, 0.0f);
    else if(currentScene == 3 || currentScene == 4) camera2->resetPosition(vec3(0.0f, 9.0f, 0.0f), -90.0f, -90.0f);
}

void Scene::setUniformsAndDrawObjects(ShaderProgram* shaderProgram, const vec3& viewPos, const vec3& lightPos, const vec3& lightColor, const vec3& objectColor, const vector<DrawableObject*>& objects, const mat4& viewMatrix, const mat4& projectionMatrix, bool useLighting, bool setColor)
{
    shaderProgram->use();
    GLuint programID = shaderProgram->getProgramID();

    if(useLighting)
    {
        GLuint viewPosLoc = glGetUniformLocation(programID, "viewPos");
        GLuint lightPosLoc = glGetUniformLocation(programID, "lightPosition");
        GLuint lightColorLoc = glGetUniformLocation(programID, "lightColor");
        glUniform3fv(viewPosLoc, 1, glm::value_ptr(viewPos));
        glUniform3fv(lightPosLoc, 1, glm::value_ptr(lightPos));
        glUniform3fv(lightColorLoc, 1, glm::value_ptr(lightColor));
    }

    if(setColor)
    {
        GLuint objectColorLoc = glGetUniformLocation(programID, "objectColor");
        glUniform3fv(objectColorLoc, 1, glm::value_ptr(objectColor));
    }

    for(auto obj : objects) obj->draw(viewMatrix, projectionMatrix);
    glUseProgram(0);
}

void Scene::rotateTrees(float deltaTime)
{
    int rotationInterval = 30;
    static float rotationSpeed = glm::radians(20.0f);
    for(int i=0; i < scene2Trees.size(); i++)
    {
        if(i % rotationInterval == 0)
        {
            scene2Trees[i]->transformationcom.addComponent(new Rotation(rotationSpeed * deltaTime, vec3(0.0f, 1.0f, 0.0f)));
        }
    }
}

void Scene::updateProjectionMatrix(int width, int height)
{
    float aspectRatio = static_cast<float>(width) / static_cast<float>(height);
    projectionMatrix = glm::perspective(glm::radians(45.0f), aspectRatio, 0.1f, 100.0f);
}

void Scene::draw(float deltaTime)
{
    if(glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) camera->processKeyboard(0, deltaTime);
    if(glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) camera->processKeyboard(1, deltaTime);
    if(glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) camera->processKeyboard(2, deltaTime);
    if(glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) camera->processKeyboard(3, deltaTime);

    if(glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) camera2->processKeyboard(0, deltaTime);
    if(glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) camera2->processKeyboard(1, deltaTime);
    if(glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) camera2->processKeyboard(2, deltaTime);
    if(glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) camera2->processKeyboard(3, deltaTime);

    mat4 view = camera->getViewMatrix(), view1 = camera2->getViewMatrix();
    mat4 projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);

    if(currentScene == 1) 
    {
        triangleShader->use();
        setUniformsAndDrawObjects(triangleShader, vec3(0.0f), vec3(0.0f), vec3(0.0f), vec3(0.0f, 0.0f, 0.0f), scene1Objects, view, projectionMatrix, false, false);
    }
    else if(currentScene == 2)
    {
        static vector<vec3> lightDirections(scene2Lights.size());
        static vector<float> timeSinceDirectionChange(scene2Lights.size(), 0.0f);
        vec3 lightPos2 = light_sc2->getPosition();
        vec3 lightColor2 = light_sc2->getColor();

        treeShader->use();
        bushShader->use();
        groundShader->use();

        rotateTrees(deltaTime);
        Light::updateLightMovement(deltaTime, scene2Lights, lightDirections, timeSinceDirectionChange);
        Light::setLightUniforms(treeShader, scene2Lights);
        setUniformsAndDrawObjects(treeShader, camera->position, lightPos2, lightColor2, vec3(0.6f, 0.3f, 0.1f), scene2Trees, view, projectionMatrix, true, true);
        Light::setLightUniforms(bushShader, scene2Lights);
        setUniformsAndDrawObjects(bushShader, camera->position, lightPos2, lightColor2, vec3(0.1f, 0.3f, 0.1f), scene2Bushes, view, projectionMatrix, true, true);
        Light::setLightUniforms(groundShader, scene2Lights);
        setUniformsAndDrawObjects(groundShader, camera->position, lightPos2, lightColor2, vec3(0.0f, 0.0f, 0.0f), scene2Ground, view, projectionMatrix, true, false);
    }
    else if(currentScene == 3)
    {
        vec3 lightPos3 = light_sc3->getPosition();
        vec3 lightColor3 = light_sc3->getColor();

		phongShader->use();
        setUniformsAndDrawObjects(phongShader, camera2->position, lightPos3, lightColor3, vec3(0.2f, 0.2f, 0.2f), scene3Objects, view1, projectionMatrix, true, true);
    }
    else if(currentScene == 4)
    {
        vec3 lightPos4 = light_sc4->getPosition();
        vec3 lightColor4 = light_sc4->getColor();

        for(auto obj : scene4Objects)
        {
            ShaderProgram* currentShader = obj->getShaderProgram();
            if(currentShader)
            {
                currentShader->use();
                setUniformsAndDrawObjects(currentShader, camera2->position, lightPos4, lightColor4, vec3(0.2f, 0.2f, 0.2f), { obj }, view1, projectionMatrix, true, true);
            }
        }
    }
}